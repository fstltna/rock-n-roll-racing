// Custom resource types
#define WAVE							256
#define RT_WAVE							MAKEINTRESOURCE(WAVE)

// Resources
#define IDI_ICON1                       101
